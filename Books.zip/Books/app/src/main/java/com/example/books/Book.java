package com.example.books;

public class Book {


    public String title;
    public String subTitle;
    public String[] authors;
    public String publisher;
    public String  publishedDate;
    public String id;

    public Book(String title, String subTitle, String[] authors,
                String publisher, String publishedDate, String id) {
        this.title = title;
        this.subTitle = subTitle;
        this.authors = authors;
        this.publisher = publisher;
        this.publishedDate = publishedDate;
        this.id = id;
    }

    public Book(String string, String string1, String s, String[] authors, String string2, String string3) {
    }
}
