package com.example.books;

public class BooksAdapter {
public class BookViewHolder extends RecyclerView.ViewHolder{}
}
